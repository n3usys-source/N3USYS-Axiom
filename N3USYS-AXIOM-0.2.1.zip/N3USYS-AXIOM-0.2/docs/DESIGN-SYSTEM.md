# N3USYS AXIOM — Design System 0.2

## Principle

AXIOM is not intended to look like a gaming desktop. It is a computational
observatory: dark, restrained, signal-driven, and structured.

## State model

VOID → SIGNAL → DISTINCTION → STATE

- VOID: #070B0F
- SURFACE: #0B1218 / #0D151C
- STRUCTURE: #263842
- SIGNAL: #00D9FF
- SIGNAL-HIGH: #66F3FF
- SECONDARY: #18A9C9
- RECURSIVE: #A394FF
- TEXT: #D7F7FF
- MUTED: #7595A1

## Visual rule

Cyan indicates an active signal.
Graphite indicates structure.
Violet indicates higher-order or recursive state.
Red/pink is reserved for negative/error conditions.

The theme should remain quiet when nothing is happening and become more
visible when the system is being interacted with.
