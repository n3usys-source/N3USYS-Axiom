# N3USYS AXIOM 0.2 — OBSERVER

A KDE Plasma visual identity for N3USYS. 0.2.1 is a stability patch for Kubuntu.

## What changed from 0.1

- Refined AXIOM color system
- More complete Plasma theme foundation
- Aurorae window-decoration foundation
- New recursive-field wallpaper
- Improved Konsole palette
- Design-system documentation
- Safer install/uninstall scripts
- Explicit Kubuntu/KDE Plasma target

## Install

Extract this archive, then run:

    ./scripts/install.sh

After installation:

1. Open KDE System Settings → Appearance → Colors.
2. Select **N3USYS AXIOM**.
3. Select the AXIOM wallpaper from Desktop & Wallpaper.
4. In Konsole, import **N3USYS-Axiom.colorscheme**.
5. Leave Window Decorations at your existing KDE decoration for this release.

## Important

This release deliberately uses a conservative KDE-native foundation.
AXIOM 0.3 can add deeper Plasma SVG component theming after the 0.2 visual
language is validated on the actual Kubuntu desktop.

## Uninstall

    ./scripts/uninstall.sh
