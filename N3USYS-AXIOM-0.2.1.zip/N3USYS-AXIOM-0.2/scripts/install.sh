#!/usr/bin/env bash
set -euo pipefail

BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

mkdir -p "$HOME/.local/share/color-schemes"
mkdir -p "$HOME/.local/share/konsole"
mkdir -p "$HOME/.local/share/wallpapers"
mkdir -p "$HOME/.local/share/plasma/desktoptheme"

cp "$BASE/colors/N3USYS-Axiom.colors" "$HOME/.local/share/color-schemes/"
cp "$BASE/konsole/N3USYS-Axiom.colorscheme" "$HOME/.local/share/konsole/"
cp "$BASE/wallpapers/N3USYS-Axiom-02.svg" "$HOME/.local/share/wallpapers/"
rm -rf "$HOME/.local/share/plasma/desktoptheme/N3USYS-Axiom"
cp -r "$BASE/plasma/desktoptheme/N3USYS-Axiom" "$HOME/.local/share/plasma/desktoptheme/"

echo
echo "N3USYS AXIOM 0.2 installed."
echo
echo "Next:"
echo "  System Settings → Appearance → Colors → N3USYS AXIOM"
echo "  Desktop → Configure Desktop and Wallpaper → N3USYS-Axiom-02.svg"
echo "  Konsole → Settings → Manage Profiles / Color Scheme"
echo
