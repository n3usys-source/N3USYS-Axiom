#!/usr/bin/env bash
set -euo pipefail

rm -f "$HOME/.local/share/color-schemes/N3USYS-Axiom.colors"
rm -f "$HOME/.local/share/konsole/N3USYS-Axiom.colorscheme"
rm -f "$HOME/.local/share/wallpapers/N3USYS-Axiom-02.svg"
rm -rf "$HOME/.local/share/plasma/desktoptheme/N3USYS-Axiom"

echo "N3USYS AXIOM 0.2 removed."
